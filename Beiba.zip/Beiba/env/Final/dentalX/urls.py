from django.urls import path
from . import views
from django.contrib.auth import views as auth_views
from .forms import changePassword

app_name = 'store'
urlpatterns = [
    path('', views.index, name="store"),
    path('test/', views.test, name="test"),
	path('cart/', views.cart, name="cart"),
	path('checkout/', views.checkout, name="checkout"),

	path('update_item/', views.updateItem, name="update_item"),
	path('process_order/', views.processOrder, name="process_order"),

	path('login/', views.loginUser, name = "login"),
    path('logout/', views.logoutUser, name = "logout"),
    path('register/', views.registerUser, name ='register'),
    path('profile/', views.profile, name ='profile'),
    path('password/', changePassword.as_view(template_name='store/password/change-password.html')),
    path('password_success/', views.password_success, name='password_success'),

]